#ifndef DLIB_REVISION_H
// Version:  18.18
// Date:     Wed Oct 28 20:26:06 EDT 2015
// Mercurial Revision ID:  cea7cff961e1
#define DLIB_MAJOR_VERSION  18
#define DLIB_MINOR_VERSION  18
#define DLIB_PATCH_VERSION  0
#endif
