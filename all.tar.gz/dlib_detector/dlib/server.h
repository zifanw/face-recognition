// Copyright (C) 2003  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_SERVEr_
#define DLIB_SERVEr_

#include "server/server_kernel.h"
#include "server/server_iostream.h"
#include "server/server_http.h"


#endif // DLIB_SERVEr_

