// Copyright (C) 2003  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_RANd_
#define DLIB_RANd_

#include "rand/rand_kernel_1.h"

#endif // DLIB_RANd_

